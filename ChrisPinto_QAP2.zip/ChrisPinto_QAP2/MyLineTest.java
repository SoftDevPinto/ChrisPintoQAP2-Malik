// Chris Pinto QAP2
// 2023-2-2

/*This code is a test class for a MyLine class that represents a line with a starting and ending point. It tests different constructor methods, getters, and setters for the starting and ending point of the line. The java.util.Arrays class is imported to use its toString() method to print the results of the tests. The code outputs the beginning and ending point of the line after each method is tested.
 */

import java.util.Arrays; // import Arrays class

public class MyLineTest { // MyLineTest class


    public static void main(String[] args) { // main method
        // Test default constructor
        MyLine line1 = new MyLine(); // create a MyLine instance
        System.out.println("Line 1 begins at " + line1.getBegin()); // invoke getBegin()
        System.out.println("Line 1 ends at " + line1.getEnd());
        System.out.println(); // print a blank line

        // Test constructor with (x1, y1, x2, y2)
        MyLine line2 = new MyLine(1, 2, 3, 4); // create a MyLine instance
        System.out.println("Line 2 begins at " + line2.getBegin()); // invoke getBegin()
        System.out.println("Line 2 ends at " + line2.getEnd());
        System.out.println(); // print a blank line

        // Test constructor with MyPoint instances
        MyPoint p1 = new MyPoint(5, 6); // create a MyPoint instance
        MyPoint p2 = new MyPoint(7, 8); // create a MyPoint instance
        MyLine line3 = new MyLine(p1, p2); // create a MyLine instance
        System.out.println("Line 3 begins at " + line3.getBegin()); // invoke getBegin()
        System.out.println("Line 3 ends at " + line3.getEnd()); // invoke getEnd()
        System.out.println(); // print a blank line

        // Test getBeginX, setBeginX, getBeginY, setBeginY
        System.out.println("Line 3 begin X: " + line3.getBeginX()); // invoke getBeginX()
        line3.setBeginX(9); // invoke setBeginX()
        System.out.println("Line 3 begin X: " + line3.getBeginX()); // invoke getBeginX()
        System.out.println("Line 3 begin Y: " + line3.getBeginY()); // invoke getBeginY()
        line3.setBeginY(10); // invoke setBeginY()
        System.out.println("Line 3 begin Y: " + line3.getBeginY()); // invoke getBeginY()
        System.out.println(); // print a blank line

        // Test getEndX, setEndX, getEndY, setEndY
        System.out.println("Line 3 end X: " + line3.getEndX()); // invoke getEndX()
        line3.setEndX(11); // invoke setEndX()
        System.out.println("Line 3 end X: " + line3.getEndX()); // invoke getEndX()
        System.out.println("Line 3 end Y: " + line3.getEndY()); // invoke getEndY()
        line3.setEndY(12);  // invoke setEndY()
        System.out.println("Line 3 end Y: " + line3.getEndY()); // invoke getEndY()
        System.out.println(); // print a blank line

        // Test getBeginXY, setBeginXY, getEndXY, setEndXY
        int[] xy = new int[2]; // create an array of length 2
        line3.getBeginXY(xy); // invoke getBeginXY()
        System.out.println("Line 3 begin XY: " + Arrays.toString(xy)); // invoke toString()
        line3.setBeginXY(13, 14); // invoke setBeginXY()
        line3.getBeginXY(xy); // invoke getBeginXY()
        System.out.println("Line 3 begin XY: " + Arrays.toString(xy)); // invoke toString()
        line3.getEndXY(xy); // invoke getEndXY()
        System.out.println("Line 3 end XY: " + Arrays.toString(xy)); // invoke toString()
        line3.setEndXY(15, 16); // invoke setEndXY()
        line3.getEndXY(xy); // invoke getEndXY()
        System.out.println("Line 3 end XY: " + Arrays.toString(xy)); // invoke toString()
        System.out.println(); // print a blank line

    }
}

        
