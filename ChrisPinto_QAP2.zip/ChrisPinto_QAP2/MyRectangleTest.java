// Chris Pinto QAP2
// 2023-2-2

// his code is a test driver for the MyRectangle class. It creates three instances of MyRectangle using different constructors, retrieves information about their top-left and bottom-right corners using the getters, and calculates the perimeter and area of the third rectangle using the getPerimeter and getArea methods. Finally, it outputs the results to the console.

public class MyRectangleTest {
    public static void main(String[] args) { // main method
        // Test default constructor
        MyRectangle rect1 = new MyRectangle(); // create a MyRectangle instance
        System.out.println("Rectangle 1 top-left corner: " + rect1.getTopLeft()); // invoke getTopLeft()
        System.out.println("Rectangle 1 bottom-right corner: " + rect1.getBottomRight()); // invoke getBottomRight()
        System.out.println();

        // Test constructor with (x1, y1, x2, y2)
        MyRectangle rect2 = new MyRectangle(1, 2, 3, 4);    // create a MyRectangle instance
        System.out.println("Rectangle 2 top-left corner: " + rect2.getTopLeft()); // invoke getTopLeft()
        System.out.println("Rectangle 2 bottom-right corner: " + rect2.getBottomRight()); // invoke getBottomRight()
        System.out.println();

        // Test constructor with MyPoint instances
        MyPoint p1 = new MyPoint(5, 6); // create a MyPoint instance
        MyPoint p2 = new MyPoint(7, 8); // create a MyPoint instance
        MyRectangle rect3 = new MyRectangle(p1, p2); // create a MyRectangle instance
        System.out.println("Rectangle 3 top-left corner: " + rect3.getTopLeft()); // invoke getTopLeft()
        System.out.println("Rectangle 3 bottom-right corner: " + rect3.getBottomRight()); // invoke getBottomRight()
        System.out.println(); // print a blank line

        // Test getPerimeter and getArea
        System.out.println("Rectangle 3 perimeter: " + rect3.getPerimeter()); // invoke getPerimeter()
        System.out.println("Rectangle 3 area: " + rect3.getArea()); // invoke getArea()
        System.out.println(); // print a blank line
    }
}
