// Chris Pinto QAP2
// 2023-2-9

/* The CreditCard class represents a credit card. The class contains the following attributes:

balance: The current balance on the credit card.
creditLimit: The maximum amount of money that can be charged to the credit card.
owner: The person who owns the credit card.
The class has two constructors: one that takes an owner and a creditLimit, and sets the balance to 0; and another that takes an owner, a creditLimit, and a balance.

The class provides methods for getting the balance, the creditLimit, and the owner information, as well as methods for charging money to the credit card and making payments. The charge method checks if the requested charge would exceed the credit limit, and if so, it prints a message indicating that the charge exceeds the limit. The payment method subtracts the amount of the payment from the balance.

Finally, the toString method returns a string representation of the CreditCard object, including its owner, balance, and credit limit.



 */

public class CreditCard { // CreditCard
    private Money balance; // instance variables
    private Money creditLimit; // instance variables
    private Person owner;   // instance variables

    public CreditCard(Person owner, Money creditLimit) { // constructor
        this.owner = owner; // this.owner
        this.creditLimit = creditLimit; // this.creditLimit
        this.balance = new Money(0); // this.balance
    }

    public CreditCard(Person owner, Money creditLimit, Money balance) { // constructor
        this.owner = owner; // this.owner
        this.creditLimit = creditLimit; // this.creditLimit
        this.balance = balance; // this.balance
    }

    public Money getBalance() { // getBalance()
        return balance; // this.balance
    }

    public String getPersonals() { // getPersonals()
        return owner.toString(); // this.owner
    }
    public Money getCreditLimit() { // getCreditLimit()
        return creditLimit; // this.creditLimit
    }

    public void charge(Money amount) { // charge()
        if (amount.compareTo(creditLimit.subtract(balance)) > 0) { // this.creditLimit
            System.out.println("Charge exceeds credit limit"); // this.balance
        } else { 
            balance = balance.add(amount); // this.balance
        }
    }

    public void payment(Money amount) { // payment()
        balance = balance.subtract(amount); // this.balance
    }

    public String toString() { // toString()
        return "Owner: " + owner + ": Balance: " + balance + ": Credit Limit: " + creditLimit; // this.owner
    }

    
}
