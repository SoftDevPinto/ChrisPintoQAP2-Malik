/* This code defines a Person class in Java. The class has three instance variables: lastName, firstName, and home. The class has a constructor that takes three parameters lastName, firstName, and Address object home and assigns the values to the corresponding instance variables. The class also has a toString() method, which returns the string representation of a person in the format of lastName + firstName + home. */

public class Person { // Person
    private String lastName; // instance variables
    private String firstName; // instance variables
    private Address home; // instance variables

    public Person(String lastName, String firstName, Address home) { // constructor
        this.lastName = lastName; // this.lastName
        this.firstName = firstName; // this.firstName
        this.home = home; // this.home
    }

    public String toString() { // toString()
        return lastName + "" + firstName + "" + home; // toString()
    }
}
