// Chris Pinto QAP2
// 2023-2-2

// This code defines a MyRectangle class in Java. The MyRectangle class has two instance variables: topLeft and bottomRight, both of which are instances of the MyPoint class. The MyRectangle class has four constructors:

// A default constructor that creates a new MyRectangle instance with default MyPoint instances as the top-left and bottom-right corners.
// A constructor that takes two MyPoint instances as arguments to define the top-left and bottom-right corners of the rectangle.
// A constructor that takes four integers as arguments to define the x and y coordinates of the top-left and bottom-right corners of the rectangle.
// The MyRectangle class also has getter and setter methods for the topLeft and bottomRight instance variables. In addition, the class has two methods: getArea and getPerimeter, which return the area and perimeter of the rectangle respectively. The toString method returns a string representation of the MyRectangle object.

public class MyRectangle { // MyRectangle
    private MyPoint topLeft; // instance variables
    private MyPoint bottomRight; // instance variables
    
    // default constructor
    public MyRectangle() { // MyRectangle()
        topLeft = new MyPoint(); // this.topLeft
        bottomRight = new MyPoint(); // this.bottomRight
    }
    
    // constructor with top-left and bottom-right MyPoint instances
    public MyRectangle(MyPoint topLeft, MyPoint bottomRight) { // MyRectangle()
        this.topLeft = topLeft; // this.topLeft
        this.bottomRight = bottomRight; // this.bottomRight
    }
    
    // constructor with x1, y1, x2, y2
    public MyRectangle(int x1, int y1, int x2, int y2) { // MyRectangle()
        topLeft = new MyPoint(x1, y1); // this.x1, this.y1
        bottomRight = new MyPoint(x2, y2); // this.x2, this.y2
    }
    
    // getters and setters for topLeft and bottomRight
    public MyPoint getTopLeft() { // getTopLeft()
        return topLeft; // this.topLeft
    }
    public void setTopLeft(MyPoint topLeft) { // setTopLeft()
        this.topLeft = topLeft; // this.topLeft
    }
    public MyPoint getBottomRight() { // getBottomRight()
        return bottomRight; // this.bottomRight
    }
    public void setBottomRight(MyPoint bottomRight) {  // setBottomRight()
        this.bottomRight = bottomRight; // this.bottomRight
    }
    
    // other methods
    public double getArea() { // getArea()
        int width = bottomRight.getX() - topLeft.getX(); // width
        int height = bottomRight.getY() - topLeft.getY(); // width and height
        return width * height; // width * height
    }
    public double getPerimeter() { // getPerimeter()
        int width = bottomRight.getX() - topLeft.getX(); // width
        int height = bottomRight.getY() - topLeft.getY(); // width and height
        return 2 * (width + height); // 2 * (width + height)
    }
    public String toString() { // override toString()
        return "MyRectangle[topLeft=" + topLeft + ", bottomRight=" + bottomRight + "]"; // invoke toString() of MyPoint
    }
}
