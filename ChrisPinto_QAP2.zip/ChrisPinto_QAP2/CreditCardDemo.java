// Chris Pinto QAP2
// 2023-2-9

/* The CreditCardDemo class is a program that demonstrates the use of a CreditCard object.

A Person object owner is created and assigned personal information, including a name and an address.

A CreditCard object visa is created and assigned the owner and a credit limit of 1000 (LIMIT).

The program then outputs the personal information of the owner associated with the credit card, the balance and credit limit of the credit card.

The program then attempts to perform several transactions on the credit card, such as charging and paying amounts, and prints the balance of the credit card after each transaction. If a charge exceeds the credit limit, the program outputs a message "Charge exceeds credit limit". */


public class CreditCardDemo { // CreditCardDemo
    public static void main(String[] args) { // main()
        final Money LIMIT = new Money(1000); // final Money
        final Money FIRST_AMOUNT = new Money(200); // final Money
        final Money SECOND_AMOUNT = new Money(10.02); // final Money
        final Money THIRD_AMOUNT = new Money(25); // final Money
        final Money FOURTH_AMOUNT = new Money(990); // final Money
        Person owner = new Person("Pinto", "Chris", new Address("3A Florizel Place", "St.Johns", "NL", "A1A1L3")); // Person
        CreditCard visa = new CreditCard(owner, LIMIT); // CreditCard
        System.out.println(visa.getPersonals()); // this.owner
        System.out.println("Balance: " + visa.getBalance()); // this.balance
        System.out.println("Credit Limit: " + visa.getCreditLimit()); // this.creditLimit
        System.out.println();
        System.out.println("Attempting to charge " + FIRST_AMOUNT); // this.balance
        visa.charge(FIRST_AMOUNT);
        System.out.println("Balance: " + visa.getBalance());
        System.out.println("Attempting to charge " + SECOND_AMOUNT);    // this.creditLimit
        visa.charge(SECOND_AMOUNT);
        System.out.println("Balance: " + visa.getBalance());
        System.out.println("Attempting to pay " + THIRD_AMOUNT); // this.balance
        visa.payment(THIRD_AMOUNT);
        System.out.println("Balance: " + visa.getBalance());
        System.out.println("Attempting to charge " + FOURTH_AMOUNT); // this.creditLimit
        visa.charge(FOURTH_AMOUNT);
        System.out.println("Balance: " + visa.getBalance()); // this.balance
    }
}