// MyRectangle
// +-topLeft: MyPoint
// +-bottomRight: MyPoint

// +MyRectangle(x1: int, y1: int, x2: int, y2: int)
// +MyRectangle(topLeft: MyPoint, bottomRight: MyPoint)

// +getTopLeft(): MyPoint
// +getBottomRight(): MyPoint
// +getWidth(): double
// +getHeight(): double
// +getArea(): double
// +getPerimeter(): double
// +toString(): String
// getArea()
// getPerimeter()
// getTopLeft()
// getBottomRight()
// getWidth()
// getHeight()
// toString()
// setTopLeftY()
// setBottomRightY()
// setTopLeftX()
// setBottomRightX()
// setTopLeft()
// setBottomRight()
