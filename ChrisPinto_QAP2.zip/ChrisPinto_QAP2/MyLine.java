// Chris Pinto QAP2
// 2023-2-2

/*The code defines a MyLine class in Java, which represents a line segment connecting two points in a 2D plane. The class has multiple constructors to create MyLine objects with different arguments, either with default values or with specific x and y coordinate values for each of the two points. The class has several getter and setter methods for accessing and modifying the x and y coordinate values of the two points, as well as methods to find the length of the line segment and the gradient (slope) of the line. The toString method returns a string representation of the line, including the coordinates of the two points. */

public class MyLine { // MyLine
    private MyPoint begin; // instance variables
    private MyPoint end; // instance variables

    public MyLine() { // constructor
        begin = new MyPoint(); // default constructor
        end = new MyPoint(); // default constructor
    }

    public MyLine(int x1, int y1, int x2, int y2) { // constructor
        begin = new MyPoint(x1, y1); // constructor
        end = new MyPoint(x2, y2); // constructor
    }

    public MyLine(MyPoint begin, MyPoint end) { // constructor
        this.begin = begin; // this.begin
        this.end = end; // this.end
    }

    public MyPoint getBegin() {     // get begin point
        return begin; // this.begin
    }

    public MyPoint getEnd() { // get end point
        return end; // this.end
    }

    public void setBegin(MyPoint begin) { // set begin point
        this.begin = begin; // this.begin
    }

    public void setEnd(MyPoint end) { // set end point
        this.end = end; // this.end
    }

    public int getBeginX(){ // get begin point
        return begin.getX();    // this.begin
    }

    public void setBeginX(int x) { // set begin point
        begin.setX(x); // this.begin
    }

    public int getBeginY(){ // get begin point
        return begin.getY(); // this.begin
    }

    public void setBeginY(int y) { // set begin point
        begin.setY(y); // this.begin
    }

    public int getEndX(){ // get end point
        return end.getX(); // this.end
    }

    public void setEndX(int x) { // set end point
        end.setX(x); // this.end
    }

    public int getEndY(){ // get end point
        return end.getY(); // this.end
    }

    public void setEndY(int y){ // set end point
        end.setY(0); // this.end
    }

    public void getBeginXY(int[] xy) { // get begin point
        xy[0] = begin.getX(); // this.begin
        xy[1] = begin.getY(); // this.begin
    }

    public void setBeginXY(int x, int y) { // set begin point
        begin.setX(x); // this.begin
        begin.setY(y); // this.begin
    }

    public void getEndXY(int[] xy) { // get end point
        xy[0] = end.getX(); // this.end
        xy[1] = end.getY(); // this.end
    }

    public void setEndXY(int x, int y) { // set end point
        end.setX(x); // this.end
        end.setY(y); // this.end
    }

    public double getLength() { // length = distance
        return begin.distance(end); // this.begin
    }

    public double getGradient(){ // gradient = slope
        return (end.getY() - begin.getY()) / (end.getX() - begin.getX()); // this.end
    }

    public String toString() { // string representation
        return "Line begins at " + begin.toString() + " and ends at " + end.toString(); // this.begin
    }
}
