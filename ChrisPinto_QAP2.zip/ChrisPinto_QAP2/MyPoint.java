// Chris Pinto QAP2
// 2023-2-2

// The code defines a Java class "MyPoint" which represents a point in 2D space with x and y coordinates. It has the following methods:

// 3 constructors:
// a default constructor that sets x and y to 0,
// a constructor that takes 2 int values for x and y and sets the corresponding instance variables,
// a constructor that takes another MyPoint object and sets its x and y to be the same as the given MyPoint.
// getters and setters for x and y
// a setXY method that sets both x and y
// 3 methods for calculating the distance from the current point to another point:
// one that takes two int values x and y,
// one that takes another MyPoint object,
// one that calculates the distance from the origin (0,0).
//a toString method that returns a string representation of the point in the form "Coordinates of this point are (x,y)".

public class MyPoint{ // MyPoint
    private int x;  // instance variables
    private int y;      // instance variables
    public MyPoint()    // default constructor
    {
        this.x = 0; // this.x
        this.y = 0; // this.y

    }
    public MyPoint(int x, int y ) // constructor
    {
        this.x = x; // this.x
        this.y = y; // this.y
    }
    public MyPoint(MyPoint p) // constructor
    {
        this.x = p.x; // this.x
        this.y = p.y; // this.y
    }
    public int getX() { // getX()
        return x; // this.x
    }
    public int getY() { // getY()
        return y; // this.y
    }
    public void setX(int x) { // setX()
        this.x = x; // this.x
    }
    public void setY(int y) { // setY()
        this.y = y; // this.y
    }

    public void setXY(int x, int y)     // setXY()
    {
        this.x = x; // this.x
        this.y = y; // this.y
    }

    public double distance(int x, int y) // distance()
    {
        int xDiff = this.x - x; // this.x
        int yDiff = this.y - y; // this.y
        return (Math.sqrt((xDiff*xDiff)+(yDiff*yDiff))); // distance

    }
    public double distance(MyPoint p) // distance()
    {
        int xDiff = this.x - p.x; // this.x
        int yDiff = this.y - p.y; // this.y
        return (Math.sqrt((xDiff*xDiff)+(yDiff*yDiff))); // distance

    }
    public double distance() // distance()
    {
        int xDiff = this.x; // this.x
        int yDiff = this.y; // this.y
        return (Math.sqrt((xDiff*xDiff)+(yDiff*yDiff))); // distance

    }

    public String toString() // toString()
    {
        return ("Coordinates of this point are (" + this.x + "," + this.y +")"); // this.x
    }
}