
public class Address { // Address
    private String street;  // instance variables
    private String city;   // instance variables
    private String state; // instance variables
    private String zip; // instance variables

    public Address(String street, String city, String state, String zip) { // constructor
        this.street = street; // this.street
        this.city = city;   // this.city
        this.state = state; // this.state
        this.zip = zip; // this.zip
    }

    public String toString() { // toString()
        return street + ", " + city + ", " + state + " " + zip; // toString()
    }
}
