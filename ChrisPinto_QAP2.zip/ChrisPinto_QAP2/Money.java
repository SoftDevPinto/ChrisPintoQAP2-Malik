// Chris Pinto QAP2
// 2023-2-9

//The code defines a Java class Money that represents an amount of money in dollars and cents. The class has several member variables, including dollars and cents, that represent the dollars and cents components of the amount of money, respectively.

// The class has several constructors, including a default constructor Money() that initializes the amount of money to $0.00, and a constructor Money(double amount) that takes a double as an argument and initializes the dollars and cents member variables based on the value of amount. The class also has a constructor Money(Money otherObject) that creates a new Money object with the same values as another Money object.

// The class has several methods for performing arithmetic operations with Money objects, including add() for adding two Money objects, subtract() for subtracting one Money object from another, and compareTo() for comparing two Money objects. The equals() method is used to compare two Money objects for equality.

// Finally, the class has a toString() method that returns a string representation of the Money object in the format $dollars.cents. 

public class Money { // Money
    private long dollars; // instance variables
    private long cents; // instance variables

    public Money() { // default constructor
        this.dollars = 0;   // this.dollars
        this.cents = 0; // this.cents
    }
    

    public Money(double amount) { // constructor
        this.dollars = (long) amount; // this.dollars
        this.cents = Math.round((amount - this.dollars) * 100); // this.cents
    }

    public Money(Money otherObject){ // constructor
        this.dollars = otherObject.dollars; // this.dollars
        this.cents = otherObject.cents; // this.cents
    }

    public Money add(Money otherAmount) { // add()
        Money sum = new Money(); // sum
        sum.dollars = this.dollars + otherAmount.dollars;   
        sum.cents = this.cents + otherAmount.cents;
        if (sum.cents >= 100) { 
            sum.dollars++;
            sum.cents -= 100;
        }
        return sum;
    }

    public Money subtract(Money otherAmount) { // subtract()
        Money difference = new Money();
        difference.dollars = this.dollars - otherAmount.dollars;
        difference.cents = this.cents - otherAmount.cents;
        if (difference.cents < 0) {
            difference.dollars--;
            difference.cents += 100;
        }
        return difference;
    }

    public int compareTo(Money otherObject){ // compareTo()
        if (this.dollars < otherObject.dollars) {
            return -1;
        } else if (this.dollars > otherObject.dollars) {
            return 1;
        } else if (this.cents < otherObject.cents) {
            return -1;
        } else if (this.cents > otherObject.cents) {
            return 1;
        } else {
            return 0;
        }
    }

    public boolean equals(Money otherObject) { // equals()
        return (this.dollars == otherObject.dollars && this.cents == otherObject.cents);
    }

    public String toString(){ // toString()
        String str = new String("$" + dollars + ".");
        if (cents < 10)
            str = str + "0" + cents;
        else
            str = str + cents;
        return str;
    }
    
}
