/*+----------------------------------------+
|               MyPoint                  |
+----------------------------------------+
| - x: int                               |
| - y: int                               |
+----------------------------------------+
| + MyPoint()                            |
| + MyPoint(x: int, y: int)              |
| + MyPoint(p: MyPoint)                  |
| + getX(): int                          |
| + getY(): int                          |
| + setX(x: int): void                   |
| + setY(y: int): void                   |
| + setXY(x: int, y: int): void          |
| + distance(x: int, y: int): double     |
| + distance(p: MyPoint): double         |
| + distance(): double                   |
| + toString(): String                   |
+----------------------------------------+*/
